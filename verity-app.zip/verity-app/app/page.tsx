import { Navbar } from "@/components/Navbar";
import { Hero } from "@/components/Hero";
import { JourneySteps } from "@/components/JourneySteps";
import { BusinessTeaser } from "@/components/BusinessTeaser";
import { Footer } from "@/components/Footer";

export default function Home() {
  return (
    <>
      <Navbar />
      <main>
        <Hero />
        <JourneySteps />
        <BusinessTeaser />
      </main>
      <Footer />
    </>
  );
}
