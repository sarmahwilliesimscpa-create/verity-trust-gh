"use client";

import { useState, FormEvent } from "react";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Check } from "lucide-react";

const benefits = [
  {
    title: "Be found",
    text: "Appear where customers are already searching for you.",
  },
  {
    title: "Be trusted",
    text: "A verified badge tells customers you're the real business.",
  },
  {
    title: "Be reached",
    text: "One profile with your correct phone, WhatsApp, and website.",
  },
];

export default function ForBusinessesPage() {
  const [submitted, setSubmitted] = useState(false);

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    // TODO: connect to Verity's application API / email service.
    setSubmitted(true);
  }

  return (
    <>
      <Navbar />
      <main>
        {/* Hero */}
        <section className="pt-16 pb-14 md:pt-24 md:pb-20">
          <div className="container-content">
            <div className="max-w-[620px] mx-auto text-center">
              <span className="font-mono text-[12px] uppercase tracking-wide text-gold-600 mb-4 block">
                For businesses
              </span>
              <h1 className="font-display font-semibold text-[32px] md:text-[44px] text-ink leading-[1.1]">
                Help customers find and trust your business.
              </h1>
              <p className="mt-5 text-[17px] text-muted max-w-[460px] mx-auto">
                Get verified once. Be found by every customer searching for you afterward.
              </p>
            </div>
          </div>
        </section>

        {/* Benefits */}
        <section className="pb-24" id="benefits">
          <div className="container-content">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {benefits.map((b) => (
                <div key={b.title} className="rounded-2xl border border-line bg-surface p-7">
                  <div className="w-9 h-9 rounded-full bg-navy flex items-center justify-center mb-5">
                    <Check className="w-4 h-4 text-gold-300" strokeWidth={2.5} />
                  </div>
                  <h3 className="font-display font-semibold text-[18px] text-ink mb-2">{b.title}</h3>
                  <p className="text-[14.5px] text-muted">{b.text}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Journey */}
        <section className="pb-24">
          <div className="container-content">
            <div className="rounded-2xl bg-navy text-canvas p-8 md:p-12">
              <h2 className="font-display font-semibold text-[24px] md:text-[28px] mb-8">
                How it works
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {[
                  { n: "1", t: "Submit your details", d: "Tell us about your business and how customers reach you." },
                  { n: "2", t: "Verity verifies", d: "Our team reviews and confirms your business is real." },
                  { n: "3", t: "Go live", d: "Your verified profile appears the moment customers search for you." },
                ].map((s) => (
                  <div key={s.n}>
                    <span className="font-mono text-[13px] text-gold-300">{s.n}</span>
                    <h3 className="font-display font-semibold text-[17px] mt-3 mb-1.5">{s.t}</h3>
                    <p className="text-[14px] text-canvas/55">{s.d}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Apply form */}
        <section className="pb-28" id="apply">
          <div className="container-content">
            <div className="max-w-[560px] mx-auto">
              <div className="text-center mb-10">
                <h2 className="font-display font-semibold text-[26px] md:text-[30px] text-ink">
                  Apply to get verified
                </h2>
                <p className="mt-3 text-[15.5px] text-muted">
                  Free to apply. Our team typically responds within a few business days.
                </p>
              </div>

              {!submitted ? (
                <form onSubmit={handleSubmit} className="rounded-2xl border border-line bg-surface p-7 md:p-8">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-5">
                    <Field label="Business name" id="bizName" placeholder="e.g. Pizza World" required />
                    <Field label="Category" id="category" placeholder="e.g. Restaurant" required />
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-5">
                    <Field label="Email address" id="email" type="email" placeholder="you@business.com" required />
                    <Field label="Phone / WhatsApp" id="phone" type="tel" placeholder="+233 ..." required />
                  </div>
                  <div className="mb-5">
                    <Field label="Website or social page" id="website" placeholder="Optional" />
                  </div>
                  <div className="mb-6">
                    <label htmlFor="message" className="block text-[13px] font-medium text-navy-600 mb-2">
                      Anything else we should know?
                    </label>
                    <textarea
                      id="message"
                      rows={3}
                      placeholder="Optional"
                      className="w-full rounded-lg border border-line bg-canvas px-3.5 py-3 text-[14.5px] text-ink outline-none focus:border-navy-300 transition-colors resize-y"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full rounded-full bg-ink text-canvas font-medium text-[15px] py-3.5 hover:bg-gold-500 hover:text-ink transition-colors"
                  >
                    Submit application
                  </button>
                </form>
              ) : (
                <div className="rounded-2xl border border-line bg-surface p-10 text-center">
                  <div className="w-12 h-12 rounded-full bg-navy flex items-center justify-center mx-auto mb-5">
                    <Check className="w-5 h-5 text-gold-300" strokeWidth={2.5} />
                  </div>
                  <h3 className="font-display font-semibold text-[19px] text-ink mb-1.5">
                    Application received
                  </h3>
                  <p className="text-[14.5px] text-muted">
                    Thanks — our team will review your details and follow up soon.
                  </p>
                </div>
              )}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}

function Field({
  label,
  id,
  type = "text",
  placeholder,
  required,
}: {
  label: string;
  id: string;
  type?: string;
  placeholder?: string;
  required?: boolean;
}) {
  return (
    <div>
      <label htmlFor={id} className="block text-[13px] font-medium text-navy-600 mb-2">
        {label}
      </label>
      <input
        id={id}
        name={id}
        type={type}
        placeholder={placeholder}
        required={required}
        className="w-full rounded-lg border border-line bg-canvas px-3.5 py-3 text-[14.5px] text-ink outline-none focus:border-navy-300 transition-colors"
      />
    </div>
  );
}
