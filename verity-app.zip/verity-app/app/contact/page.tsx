"use client";

import { Suspense, useState, FormEvent } from "react";
import { useSearchParams } from "next/navigation";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Check, Mail, MessageCircle, MapPin } from "lucide-react";

function ContactForm() {
  const params = useSearchParams();
  const invite = params.get("invite") ?? "";
  const [submitted, setSubmitted] = useState(false);

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    // TODO: connect to Verity's support inbox / CRM.
    setSubmitted(true);
  }

  return (
    <div className="container-content grid grid-cols-1 lg:grid-cols-2 gap-14 pt-16 pb-24 md:pt-24 md:pb-28">
      <div>
        <span className="font-mono text-[12px] uppercase tracking-wide text-gold-600 mb-4 block">
          Get in touch
        </span>
        <h1 className="font-display font-semibold text-[32px] md:text-[38px] text-ink leading-tight mb-5">
          {invite ? "Invite a business to Verity" : "We're here to help"}
        </h1>
        <p className="text-[16px] text-muted max-w-[420px] mb-10">
          {invite
            ? `Let us know about "${invite}" and we'll reach out to help them get verified.`
            : "Questions about a search result, a verified profile, or your business? Send us a message."}
        </p>

        <ul className="flex flex-col gap-5">
          <li className="flex items-center gap-3.5 text-[14.5px] text-navy-600">
            <span className="w-9 h-9 rounded-lg bg-canvas border border-line flex items-center justify-center shrink-0">
              <Mail className="w-4 h-4 text-navy-500" />
            </span>
            hello@verity.trust
          </li>
          <li className="flex items-center gap-3.5 text-[14.5px] text-navy-600">
            <span className="w-9 h-9 rounded-lg bg-canvas border border-line flex items-center justify-center shrink-0">
              <MessageCircle className="w-4 h-4 text-navy-500" />
            </span>
            +233 00 000 0000 (WhatsApp)
          </li>
          <li className="flex items-center gap-3.5 text-[14.5px] text-navy-600">
            <span className="w-9 h-9 rounded-lg bg-canvas border border-line flex items-center justify-center shrink-0">
              <MapPin className="w-4 h-4 text-navy-500" />
            </span>
            Accra, Ghana
          </li>
        </ul>
      </div>

      <div>
        {!submitted ? (
          <form onSubmit={handleSubmit} className="rounded-2xl border border-line bg-surface p-7 md:p-8">
            <div className="mb-5">
              <label htmlFor="name" className="block text-[13px] font-medium text-navy-600 mb-2">
                Your name
              </label>
              <input
                id="name"
                required
                className="w-full rounded-lg border border-line bg-canvas px-3.5 py-3 text-[14.5px] text-ink outline-none focus:border-navy-300 transition-colors"
              />
            </div>
            <div className="mb-5">
              <label htmlFor="email" className="block text-[13px] font-medium text-navy-600 mb-2">
                Email address
              </label>
              <input
                id="email"
                type="email"
                required
                className="w-full rounded-lg border border-line bg-canvas px-3.5 py-3 text-[14.5px] text-ink outline-none focus:border-navy-300 transition-colors"
              />
            </div>
            <div className="mb-6">
              <label htmlFor="message" className="block text-[13px] font-medium text-navy-600 mb-2">
                Message
              </label>
              <textarea
                id="message"
                rows={4}
                defaultValue={invite ? `I'd like to invite "${invite}" to join Verity.` : ""}
                required
                className="w-full rounded-lg border border-line bg-canvas px-3.5 py-3 text-[14.5px] text-ink outline-none focus:border-navy-300 transition-colors resize-y"
              />
            </div>
            <button
              type="submit"
              className="w-full rounded-full bg-ink text-canvas font-medium text-[15px] py-3.5 hover:bg-gold-500 hover:text-ink transition-colors"
            >
              Send message
            </button>
          </form>
        ) : (
          <div className="rounded-2xl border border-line bg-surface p-10 text-center">
            <div className="w-12 h-12 rounded-full bg-navy flex items-center justify-center mx-auto mb-5">
              <Check className="w-5 h-5 text-gold-300" strokeWidth={2.5} />
            </div>
            <h3 className="font-display font-semibold text-[19px] text-ink mb-1.5">Message sent</h3>
            <p className="text-[14.5px] text-muted">We&apos;ll get back to you shortly.</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default function ContactPage() {
  return (
    <>
      <Navbar />
      <main>
        <Suspense fallback={null}>
          <ContactForm />
        </Suspense>
      </main>
      <Footer />
    </>
  );
}
