"use client";

import { useState } from "react";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { faqs } from "@/lib/data";
import { ChevronDown } from "lucide-react";

export default function ResourcesPage() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <>
      <Navbar />
      <main>
        <section className="pt-16 pb-12 md:pt-24 md:pb-16">
          <div className="container-content">
            <div className="max-w-[560px] mx-auto text-center">
              <h1 className="font-display font-semibold text-[32px] md:text-[40px] text-ink leading-tight">
                Help Center
              </h1>
              <p className="mt-4 text-[16px] text-muted">
                Answers to common questions about searching, connecting, and getting verified.
              </p>
            </div>
          </div>
        </section>

        <section className="pb-28" id="faqs">
          <div className="container-content">
            <div className="max-w-[680px] mx-auto flex flex-col gap-3">
              {faqs.map((item, i) => {
                const isOpen = open === i;
                return (
                  <div key={item.q} className="rounded-xl border border-line bg-surface overflow-hidden">
                    <button
                      onClick={() => setOpen(isOpen ? null : i)}
                      className="w-full flex items-center justify-between gap-4 text-left px-6 py-5"
                      aria-expanded={isOpen}
                    >
                      <span className="text-[15.5px] font-medium text-ink">{item.q}</span>
                      <ChevronDown
                        className={`w-4 h-4 text-muted shrink-0 transition-transform ${
                          isOpen ? "rotate-180" : ""
                        }`}
                      />
                    </button>
                    {isOpen && (
                      <div className="px-6 pb-5 text-[14.5px] text-muted leading-relaxed">{item.a}</div>
                    )}
                  </div>
                );
              })}
            </div>

            <div className="max-w-[680px] mx-auto mt-10 rounded-2xl bg-canvas border border-line p-7 text-center">
              <p className="text-[14.5px] text-muted mb-4">Still need help?</p>
              <a
                href="/contact"
                className="inline-flex items-center rounded-full bg-ink text-canvas text-[14px] font-medium px-5 py-2.5 hover:bg-gold-500 hover:text-ink transition-colors"
              >
                Contact support
              </a>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
