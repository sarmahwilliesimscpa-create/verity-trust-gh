import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Verity — Find businesses you can trust",
  description:
    "Search for a business, confirm it's real, and connect directly. Verity helps customers find genuine businesses and helps businesses be found.",
  metadataBase: new URL("https://verity.trust"),
  openGraph: {
    title: "Verity — Find businesses you can trust",
    description: "Search for a business, confirm it's real, and connect directly.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="font-sans antialiased">{children}</body>
    </html>
  );
}
